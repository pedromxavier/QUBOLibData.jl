# arXiv_1903_10928_3r3x

Source: "_Equation Planting: A Tool for Benchmarking Ising Machines_"
Authors: Itay Hen

| Problem   | 3-Regular 3-XORSAT |
|:---------:|:------------------:|
| Instances | 3202               |
